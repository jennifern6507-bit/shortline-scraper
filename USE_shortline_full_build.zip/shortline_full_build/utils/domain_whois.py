import whois


def lookup_domain_info(url):
    """
    Parse WHOIS info for domain.
    Returns registrar, org, creation year.
    """

    try:
        w = whois.whois(url)

        return {
            "registrar": w.registrar,
            "org": w.org,
            "created": str(w.creation_date[0]) if isinstance(w.creation_date, list) else str(w.creation_date)
        }

    except Exception:
        return {
            "registrar": None,
            "org": None,
            "created": None
        }
