import csv
import os


def export_to_csv(filename, rows):
    """
    Save rows to CSV file.
    """

    if not rows:
        return

    fieldnames = [
        "url",
        "company",
        "ceo",
        "procurement",
        "mow",
        "engineering",
        "emails",
        "phones",
        "address",
        "state",
        "country",
        "website",
        "domain_registrar",
        "domain_org",
        "domain_created"
    ]

    os.makedirs("exports", exist_ok=True)

    with open(f"exports/{filename}", "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()

        for row in rows:
            writer.writerow(row)
