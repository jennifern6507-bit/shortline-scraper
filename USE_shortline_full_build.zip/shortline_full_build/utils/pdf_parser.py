import requests
from PyPDF2 import PdfReader
import io
import re


def extract_contacts_from_pdf(url):
    """Downloads PDF + extracts emails and phone numbers."""
    try:
        r = requests.get(url, timeout=10)
        pdf = PdfReader(io.BytesIO(r.content))

        text = ""
        for page in pdf.pages:
            text += page.extract_text() or ""

        emails = list(set(re.findall(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", text)))
        phones = list(set(re.findall(r"\(?\d{3}\)?[-\s.]?\d{3}[-\s.]?\d{4}", text)))

        return {"emails": emails, "phones": phones}

    except Exception:
        return {"emails": [], "phones": []}
