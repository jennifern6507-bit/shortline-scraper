import re

STATE_MAP = {
    "Alabama": "AL", "Alaska": "AK", "Arizona": "AZ", "Arkansas": "AR",
    "California": "CA", "Colorado": "CO", "Connecticut": "CT", "Delaware": "DE",
    "Florida": "FL", "Georgia": "GA", "Idaho": "ID", "Illinois": "IL",
    "Indiana": "IN", "Iowa": "IA", "Kansas": "KS", "Kentucky": "KY",
    "Louisiana": "LA", "Maine": "ME", "Maryland": "MD", "Massachusetts": "MA",
    "Michigan": "MI", "Minnesota": "MN", "Mississippi": "MS", "Missouri": "MO",
    "Montana": "MT", "Nebraska": "NE", "Nevada": "NV", "New Hampshire": "NH",
    "New Jersey": "NJ", "New Mexico": "NM", "New York": "NY",
    "North Carolina": "NC", "North Dakota": "ND", "Ohio": "OH",
    "Oklahoma": "OK", "Oregon": "OR", "Pennsylvania": "PA",
    "Rhode Island": "RI", "South Carolina": "SC", "South Dakota": "SD",
    "Tennessee": "TN", "Texas": "TX", "Utah": "UT", "Vermont": "VT",
    "Virginia": "VA", "Washington": "WA", "West Virginia": "WV",
    "Wisconsin": "WI", "Wyoming": "WY"
}


def detect_state(text):
    """Detect US state names in large railroad descriptions."""
    for name, code in STATE_MAP.items():
        if name.lower() in text.lower():
            return code

    # Abbreviation search
    for code in STATE_MAP.values():
        if re.search(rf"\b{code}\b", text):
            return code

    return None


ROLE_REGEX = {
    "ceo": ["ceo", "chief executive", "president"],
    "procurement": ["procurement", "purchasing", "buyer", "supply chain"],
    "engineering": ["chief engineer", "engineering department", "rail engineer"],
    "mow": ["maintenance of way", "roadmaster", "track supervisor"]
}


def extract_role_contacts(text, ai_data):
    """
    Merge AI extraction + regex keyword extraction.
    """

    contacts = {
        "ceo": None,
        "procurement": None,
        "engineering": None,
        "mow": None
    }

    # Prefer AI data
    if ai_data:
        for role, data in ai_data.items():
            if data and isinstance(data, dict):
                if data.get("name"):
                    contacts[role] = data

    # Fallback regex search
    for role, patterns in ROLE_REGEX.items():
        if contacts[role]:
            continue

        for p in patterns:
            m = re.search(rf"{p}[^\w]+([A-Z][a-z]+(?:\s[A-Z][a-z]+)?)", text, re.I)
            if m:
                contacts[role] = {
                    "name": m.group(1),
                    "title": p.title(),
                    "source": "regex"
                }
                break

    return contacts
