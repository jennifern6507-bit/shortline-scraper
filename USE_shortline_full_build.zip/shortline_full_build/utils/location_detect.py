import re
from .contact_extractor import STATE_MAP


def detect_location(text):
    """
    Detect city, state, or country from large railroad webpages.
    """

    text_lower = text.lower()

    # --- State Detection ---
    detected_state = None
    for name, code in STATE_MAP.items():
        if name.lower() in text_lower:
            detected_state = code
            break

    if not detected_state:
        for code in STATE_MAP.values():
            if re.search(rf"\b{code}\b", text):
                detected_state = code
                break

    # --- City Detection (basic) ---
    city_match = re.search(r"([A-Z][a-z]+(?:\s[A-Z][a-z]+)*),\s(" + "|".join(STATE_MAP.values()) + ")", text)
    if city_match:
        return {
            "city": city_match.group(1),
            "state": city_match.group(2),
            "country": "USA"
        }

    # --- Fallback: Only state ---
    if detected_state:
        return {
            "city": None,
            "state": detected_state,
            "country": "USA"
        }

    # --- Detect Canada ---
    if "canada" in text_lower:
        return {"city": None, "state": None, "country": "Canada"}

    # --- Detect Mexico ---
    if "mexico" in text_lower:
        return {"city": None, "state": None, "country": "Mexico"}

    return {"city": None, "state": None, "country": None}
