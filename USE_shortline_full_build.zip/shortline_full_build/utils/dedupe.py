def dedupe_items(items):
    """
    Remove duplicates based on URL or company name.
    """

    seen = set()
    cleaned = []

    for item in items:
        key = (item.get("url") or "") + "|" + (item.get("company") or "")

        if key not in seen:
            seen.add(key)
            cleaned.append(item)

    return cleaned
