import openai
import os

openai.api_key = os.getenv("OPENAI_API_KEY")


def extract_entities(text, url):
    """Use OpenAI to extract structured railroad contacts."""

    prompt = f"""
    Extract railroad leadership contacts from the following webpage text.

    URL: {url}

    Text:
    {text[:5000]}

    Return JSON with:
    - ceo: {{"name": "", "title": ""}}
    - procurement: {{"name": "", "title": ""}}
    - engineering: {{"name": "", "title": ""}}
    - mow: {{"name": "", "title": ""}}
    """

    try:
        response = openai.chat.completions.create(
            model="gpt-5.1",
            messages=[{"role": "system", "content": "Extract railroad contacts."},
                      {"role": "user", "content": prompt}]
        )

        data = response.choices[0].message.content

        import json
        return json.loads(data)

    except Exception:
        return {}

