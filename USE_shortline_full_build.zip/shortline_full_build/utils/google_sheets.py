from google.oauth2 import service_account
from googleapiclient.discovery import build


class GoogleSheetsClient:
    def __init__(self, creds_path, sheet_id, sheet_name):
        scopes = ["https://www.googleapis.com/auth/spreadsheets"]

        creds = service_account.Credentials.from_service_account_file(
            creds_path, scopes=scopes
        )

        self.sheet_id = sheet_id
        self.sheet_name = sheet_name

        self.service = build("sheets", "v4", credentials=creds)
        self.sheet = self.service.spreadsheets()

    def append_rows(self, rows):
        """Batch append multiple rows in ONE API request."""
        body = {"values": rows}

        request = (
            self.sheet.values()
            .append(
                spreadsheetId=self.sheet_id,
                range=f"{self.sheet_name}!A1",
                valueInputOption="USER_ENTERED",
                body=body,
            )
        )

        return request.execute()

