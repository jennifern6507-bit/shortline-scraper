import requests
from bs4 import BeautifulSoup
import re


def google_search_company(name):
    """
    Performs a lightweight Google search to guess the official company domain.
    """

    query = name + " railroad official site"
    url = "https://www.google.com/search?q=" + requests.utils.quote(query)

    headers = {
        "User-Agent": "Mozilla/5.0"
    }

    try:
        r = requests.get(url, headers=headers, timeout=10)
        soup = BeautifulSoup(r.text, "html.parser")

        # Extract visible search result URLs
        results = soup.select("a")

        for a in results:
            href = a.get("href", "")

            # Example: "/url?q=https://www.bnsf.com&sa=..."
            if href.startswith("/url?q="):
                domain = href.split("/url?q=")[1].split("&")[0].strip()

                # filter out junk
                if "google" in domain:
                    continue
                if domain.startswith("http"):
                    return domain

        return None

    except Exception:
        return None
