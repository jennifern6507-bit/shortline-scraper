BOT_NAME = "scraper"

SPIDER_MODULES = ["scraper.spiders"]
NEWSPIDER_MODULE = "scraper.spiders"

ROBOTSTXT_OBEY = True
DOWNLOAD_DELAY = 1

ITEM_PIPELINES = {
    "scraper.pipelines.GoogleSheetsPipeline": 300,
}

GOOGLE_SHEETS_CREDS = "keys/shortlinescraper.json"
GOOGLE_SHEETS_ID = "1IRurUH9-NksT2nOLOrHg7UU7g5znaYM8FG9bz-EC9RM"
GOOGLE_SHEETS_SHEET = "contacts"

FEED_EXPORT_ENCODING = "utf-8"

