import scrapy

class ContactItem(scrapy.Item):
    url = scrapy.Field()
    contacts = scrapy.Field()
    hq_address = scrapy.Field()
    emails = scrapy.Field()
    phones = scrapy.Field()
    pdfs_checked = scrapy.Field()
    source = scrapy.Field()
    domain = scrapy.Field()
    state = scrapy.Field()
