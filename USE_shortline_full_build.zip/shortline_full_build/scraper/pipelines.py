from itemadapter import ItemAdapter
from utils.google_sheets import GoogleSheetsClient
import csv
import os

class GoogleSheetsPipeline:
    def __init__(self):
        self.rows_buffer = []

    @classmethod
    def from_crawler(cls, crawler):
        creds = crawler.settings.get("GOOGLE_SHEETS_CREDS")
        sheet_id = crawler.settings.get("GOOGLE_SHEETS_ID")
        sheet_name = crawler.settings.get("GOOGLE_SHEETS_SHEET")

        pipeline = cls()
        pipeline.client = GoogleSheetsClient(creds, sheet_id, sheet_name)
        return pipeline

    def process_item(self, item, spider):
        a = ItemAdapter(item)

        row = [
            a.get("url", ""),
            a.get("domain", ""),
            a.get("state", "") or "",
            a.get("contacts", {}).get("ceo") or "",
            a.get("contacts", {}).get("procurement") or "",
            a.get("contacts", {}).get("mow") or "",
            a.get("contacts", {}).get("engineering") or "",
            ", ".join(a.get("emails", [])),
            ", ".join(a.get("phones", [])),
            a.get("hq_address", "") or "",
        ]

        self.rows_buffer.append(row)
        return item

    def close_spider(self, spider):
        if not self.rows_buffer:
            return

        # Batch write to Google Sheets
        print(f"Writing {len(self.rows_buffer)} rows to Google Sheets...")
        self.client.append_rows(self.rows_buffer)

        # Also export CSV
        csv_path = "results.csv"
        print(f"Writing CSV: {csv_path}")

        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow([
                "URL", "Domain", "State",
                "CEO", "Procurement", "MOW", "Engineering",
                "Emails", "Phones", "Address"
            ])
            writer.writerows(self.rows_buffer)

