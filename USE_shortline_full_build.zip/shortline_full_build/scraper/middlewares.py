from scrapy import signals

class ScraperSpiderMiddleware:
    @classmethod
    def from_crawler(cls, crawler):
        return cls()

class ScraperDownloaderMiddleware:
    @classmethod
    def from_crawler(cls, crawler):
        return cls()
