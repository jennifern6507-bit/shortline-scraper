import scrapy
import re
import tldextract
from utils.openai_extract import extract_entities
from utils.contact_extractor import extract_role_contacts
from utils.text_cleaner import clean_text
from utils.pdf_parser import extract_contacts_from_pdf
from utils.contact_extractor import detect_state
from scraper.items import ContactItem


class ShortlineContactsSpider(scrapy.Spider):
    name = "shortline_contacts"

    start_urls = [
        "https://railserve.com/rail-directory/shortlines-regional-railroads/",
        "https://en.wikipedia.org/wiki/List_of_shortline_railroads_in_the_United_States",
        "https://en.wikipedia.org/wiki/List_of_Canadian_railways",
        "https://en.wikipedia.org/wiki/List_of_Mexican_railroads",
    ]

    def parse(self, response):

        # Railserve links
        if "railserve.com" in response.url:
            for href in response.css("a::attr(href)").getall():
                if href and ("rail" in href.lower() or "rr" in href.lower()):
                    yield response.follow(href, callback=self.parse_railroad_page)

        # Wikipedia list pages
        if "wikipedia.org" in response.url:
            for href in response.css("div.mw-parser-output a::attr(href)").getall():
                if href and href.startswith("/wiki/"):
                    bad = ["station", "metro", "tram", "bus", "subway"]
                    if any(b in href.lower() for b in bad):
                        continue
                    yield response.follow(href, callback=self.parse_railroad_page)

    def parse_railroad_page(self, response):
        raw_text = clean_text(" ".join(response.css("*::text").getall()))

        item = ContactItem()
        item["url"] = response.url
        item["emails"] = self.extract_emails(response)
        item["phones"] = self.extract_phones(raw_text)
        item["hq_address"] = None
        item["contacts"] = {}
        item["pdfs_checked"] = []

        # Domain parsing
        domain = tldextract.extract(response.url).registered_domain
        item["domain"] = domain

        # State detection
        state = detect_state(raw_text)
        item["state"] = state

        # PDF scanning
        pdf_links = response.css("a[href$='.pdf']::attr(href)").getall()
        for pdf in pdf_links:
            if pdf.startswith("/"):
                pdf = response.urljoin(pdf)
            pdf_contacts = extract_contacts_from_pdf(pdf)
            item["pdfs_checked"].append({pdf: pdf_contacts})

        # AI role extraction
        ai_data = extract_entities(raw_text, response.url)

        # merge
        item["contacts"] = extract_role_contacts(raw_text, ai_data)

        return item

    def extract_emails(self, response):
        return list(set([
            e.replace("mailto:", "").strip()
            for e in response.css("a[href^=mailto]::attr(href)").getall()
        ]))

    def extract_phones(self, text):
        return list(set(re.findall(
            r"(\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4})", text
        )))

