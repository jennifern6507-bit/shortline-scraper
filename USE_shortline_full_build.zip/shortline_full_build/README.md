\# Shortline Railroad Contact Scraper



This project scrapes Shortline, Regional, and Class III railroad contact data from:

\- Railserve directory

\- Wikipedia shortline lists (US / Canada / Mexico)

\- Additional linked railroad pages



\## Features

\- CEO, Procurement, MOW, Engineering detection

\- Email + phone extraction

\- Address best-effort parsing

\- PDF parsing for contacts

\- Google Sheets batch writer

\- WHOIS domain extraction

\- AI-powered entity extraction (OpenAI)

\- Duplicate filtering

\- CSV export

\- Full Scrapy framework



\## Run

```bash

scrapy crawl shortline\_contacts



